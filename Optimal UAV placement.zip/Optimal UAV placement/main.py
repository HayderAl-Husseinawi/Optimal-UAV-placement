from copy import deepcopy
import os
import pandas as pd
from core.io.load_data import load_turbine_data
from core.io.save_results import ResultsExporter
from core.model.shared import PhysicalState
from core.algorithms.optimization import OptimizationManager

from core.utils.results_analyzer.plot_convergence import plot_convergence_of_results
from core.utils.results_analyzer.plot_ranks import plot_rank_of_results
from core.utils.results_analyzer.run_average_analysis import average_results_analysis
from core.utils.results_analyzer.write_analysis import write_analysis_into_csv
from core.utils.results_analyzer.write_results import write_results_into_csv
from core.utils.setting import Settings

exporter = ResultsExporter()


####################################    LOAD DATA    ####################################
data = load_turbine_data(Settings.turbine_data_path)


####################################    CREATE OBJECTS (TURBINES AND DRONES)    ####################################
physical_state = PhysicalState()
physical_state.create_turbines(turbine_dataframe=data)
physical_state.create_drones(
    Settings.drone_speed_mps,
    Settings.drone_max_flight_time_mins,
    Settings.drone_max_coverage,
)


####################################    CREATE RESULTS PATH    ####################################
os.makedirs(Settings.get_results_path(), exist_ok=True)


####################################    MAIN PLOTS    ####################################
exporter.save_main_plots(physical_state)


####################################    OPTIMIZATION    ####################################
save_path = f"{Settings.get_results_path()}/1_placement"
os.makedirs(save_path, exist_ok=True)

optimizer = OptimizationManager(
    physical_state,
    results_path=save_path,
)
results = optimizer.optimize()
optimized_drones, optimized_placements = exporter.save_optimization_results(
    physical_state, results, save_path
)


####################################    SAVE SUMMARY    ####################################
exporter.save_coverage_summary(
    physical_state,
    optimized_drones,
    optimized_placements,
    Settings.get_results_path(),
)


####################################    RESULTS ANALYSIS    ####################################
write_results_into_csv(
    results_path=os.path.join(Settings.get_results_path(), "1_placement")
)
write_analysis_into_csv(
    results_path=os.path.join(Settings.get_results_path(), "1_placement")
)
plot_convergence_of_results(
    results_path=os.path.join(Settings.get_results_path(), "1_placement")
)
plot_rank_of_results(
    results_path=os.path.join(Settings.get_results_path(), "1_placement")
)
