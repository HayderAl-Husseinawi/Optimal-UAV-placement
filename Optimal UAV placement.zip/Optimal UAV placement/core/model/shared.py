from pandas import DataFrame
from core.model.drone import Drone
from core.model.turbine import Turbine


class PhysicalState:
    def __init__(self):
        self._turbines: list[Turbine] = []
        self._drones: list[Drone] = []

    @property
    def turbines(self) -> list[Turbine]:
        return self._turbines

    @property
    def drones(self) -> list[Drone]:
        return self._drones

    @property
    def num_turbines(self) -> int:
        return len(self._turbines)

    @property
    def num_drones(self) -> int:
        return len(self._drones)

    def create_turbines(self, turbine_dataframe: DataFrame):
        for _, row in turbine_dataframe.iterrows():
            self._turbines.append(Turbine(id=row["Turbine"], x=row["x"], y=row["y"]))

    def create_drones(
        self,
        speed_mps: int,
        fly_max_time_minutes: int,
        turbine_coverage: int,
    ):
        for i, turbine in enumerate(self.turbines):
            self._drones.append(
                Drone(
                    id=i,
                    x=turbine.x,
                    y=turbine.y,
                    speed_mps=speed_mps,
                    fly_max_time_minutes=fly_max_time_minutes,
                    max_coverage=turbine_coverage,
                )
            )

    def update_drone_by_id(
        self,
        drone_id: int,
        *,
        x: float | None = None,
        y: float | None = None,
        speed_mps: float | None = None,
        fly_max_time_minutes: int | None = None,
        max_coverage: int | None = None,
    ) -> None:
        for drone in self._drones:
            if drone.id == drone_id:
                if x is not None:
                    drone.x = x
                if y is not None:
                    drone.y = y
                if speed_mps is not None:
                    drone.speed_mps = speed_mps
                if fly_max_time_minutes is not None:
                    drone.fly_max_time_minutes = fly_max_time_minutes
                if max_coverage is not None:
                    drone.max_coverage = max_coverage
                return

        raise ValueError(f"Drone with id={drone_id} not found")

    def replace_drones(self, new_drones: list[Drone]):
        self._drones.clear()
        self._drones.extend(new_drones)
