from core.utils.setting import Settings


class Drone:
    def __init__(self, id, x, y, speed_mps, fly_max_time_minutes, max_coverage):
        self.id = id
        self.x = x
        self.y = y
        self.speed_mps = speed_mps
        self.fly_max_time_minutes = fly_max_time_minutes
        self.max_coverage = max_coverage
        # original_index

    def get_radius(self):
        """
        Calculate maximum coverage radius in meters.
        Radius = Speed (m/s) * (Time (min) * 60) / 2
        Divided by 2 because the drone must return.
        """
        return self.speed_mps * (self.fly_max_time_minutes * 60) / 2
