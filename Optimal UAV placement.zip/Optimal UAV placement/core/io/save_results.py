import csv
import os
import pandas as pd
from core.io.plotter import Plotter
from core.utils.setting import Settings


class ResultsExporter:
    def __init__(self):
        pass

    def save_optimization_results(self, physical_state, results, save_path):
        optimized_drones_indices = results["selected_drones_indices"]
        optimized_placements = results["placements"]
        best_algo_name = results["best_algo_name"]
        # best_trial_id = results["best_trial_id"]

        # Create DataFrame for results
        output_rows = []
        for drone_idx in optimized_drones_indices:
            drone_loc = physical_state.turbines[drone_idx]
            covered_indices = optimized_placements[drone_idx]
            covered_names = [physical_state.turbines[idx].id for idx in covered_indices]

            output_rows.append(
                {
                    "Drone_ID": physical_state.drones[drone_idx].id,
                    "Location_Turbine_Name": drone_loc.id,
                    "Latitude": drone_loc.x,
                    "Longitude": drone_loc.y,
                    "Covered_Count": len(covered_names),
                    "Covered_Turbines": ", ".join(covered_names),
                }
            )
        optimization_results_df = pd.DataFrame(output_rows)
        save_path = f"{save_path}/best_placements_by_{best_algo_name}"
        os.makedirs(save_path, exist_ok=True)

        optimization_results_df.to_csv(
            f"{save_path}/optimized_placements.csv",
            index=False,
        )
        optimized_drones = [physical_state.drones[i] for i in optimized_drones_indices]
        plt = Plotter(save_path=f"{save_path}")
        plt.plot_drones_turbines(
            turbines=physical_state.turbines,
            drones=optimized_drones,
            title="Drone Placement Distribution",
            filename=f"optimized_placements",
        )
        return optimized_drones, optimized_placements

    def save_main_plots(self, physical_state):
        plt = Plotter(save_path=f"{Settings.get_results_path()}/0_main_plots")
        plt.plot_drones_turbines(
            turbines=physical_state.turbines,
            title="Turbines Distribution",
            filename="turbines",
        )
        plt.plot_drones_turbines(
            turbines=physical_state.turbines,
            drones=physical_state.drones,
            title="Turbines and Drones Distribution",
            filename="turbines_and_drones",
        )

    def save_coverage_summary(
        self,
        physical_state,
        optimized_drones,
        optimized_placements,
        save_path,
    ):
        # Construct summary
        summary = [
            ("PHASE", "METRIC", "VALUE"),
            ("GENERAL", "Total Turbines", physical_state.num_turbines),
            ("GENERAL", "Total Drones", physical_state.num_drones),
            # Optimization
            ("OPTIMIZATION", "Selected Drones", len(optimized_drones)),
            (
                "OPTIMIZATION",
                "Turbines Covered",
                sum(len(v) for v in optimized_placements.values()),
            ),
        ]

        # print
        print("\n" + "=" * 60)
        print(" WIND TURBINE DRONE COVERAGE SUMMARY ")
        print("=" * 60)

        current_phase = None
        for phase, metric, value in summary[1:]:
            if phase != current_phase:
                print("\n" + phase.replace("_", " "))
                print("-" * 60)
                current_phase = phase

            print(f"  ▸ {metric:<25}: {value}")

        print("=" * 60 + "\n")

        # save
        csv_file = f"{save_path}/coverage_summary.csv"

        with open(csv_file, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerows(summary)
