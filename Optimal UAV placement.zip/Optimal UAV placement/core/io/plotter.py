from matplotlib.patches import Ellipse
import matplotlib.pyplot as plt
import os
import numpy as np

from core.model.drone import Drone
from core.utils.setting import Settings


class Plotter:
    def __init__(self, save_path: str, figsize: tuple = (10, 4)):
        self.save_path = save_path
        self.figsize = figsize  # Global figure size
        os.makedirs(self.save_path, exist_ok=True)

    def _save_and_close(self, filename):
        plt.tight_layout()
        plt.savefig(os.path.join(self.save_path, f"{filename}.svg"))
        plt.close()

    def plot_drones_turbines(
        self,
        turbines,
        drones=None,
        title="Drones Placements Map",
        filename="drone_placement",
    ):

        plt.figure(figsize=self.figsize)

        # Calculate mean latitude for projection correction
        if drones:
            mean_lat = np.mean([d.x for d in drones])  # y = latitude
        elif turbines:
            mean_lat = np.mean([t.x for t in turbines])  # y = latitude
        else:
            mean_lat = 0

        # Cosine of latitude factor for longitude distance
        cos_lat = np.cos(np.radians(mean_lat))

        # Plot turbines
        self._plot_turbines(turbines)

        ax = plt.gca()

        # Plot operational drones
        if drones:
            self._plot_drones_with_coverage(
                drones,
                ax,
                color="green",
                marker="*",
                label="Operational drone",
                cos_lat=cos_lat,
            )

        plt.title(title)
        plt.xlabel("Longitude (x)")  # x = longitude
        plt.ylabel("Latitude (y)")  # y = latitude

        # Remove duplicate labels in legend
        handles, labels = ax.get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        plt.legend(by_label.values(), by_label.keys())

        # Set aspect ratio to compensate for latitude distortion
        ax.set_aspect(1.0 / cos_lat)

        self._save_and_close(filename)

    def _plot_turbines(self, turbines):
        """Plot turbines as gold points."""
        turbine_x = [t.x for t in turbines]  # longitude
        turbine_y = [t.y for t in turbines]  # latitude
        plt.scatter(turbine_x, turbine_y, c="gold", s=25, label="Turbine")

    def _plot_drones_with_coverage(
        self, drones: list[Drone], ax, color, marker, label, cos_lat=1.0
    ):
        """
        Plot drones with their coverage areas (Ellipses).
        """

        for drone in drones:
            radius_m = drone.get_radius()

            # Width in degrees (longitude direction, affected by cos(lat))
            width_deg = 2 * radius_m / (Settings.METERS_PER_DEGREE * cos_lat)

            # Height in degrees (latitude direction, not affected)
            height_deg = 2 * radius_m / Settings.METERS_PER_DEGREE

            if drone.max_coverage > Settings.drone_max_coverage:
                local_color = "purple"
                local_label = "Recovered drone"
            else:
                local_color = color
                local_label = label

            # Plot drone markers
            plt.scatter(
                drone.x,
                drone.y,
                c=local_color,
                s=15,
                marker=marker,
                label=f"{local_label} center",
            )

            # Draw drone coverage ellipses
            ellipse = Ellipse(
                (drone.x, drone.y),
                width=width_deg,
                height=height_deg,
                color=local_color,
                fill=False,
                alpha=0.4,
                linewidth=1,
                label=f"{local_label} coverage",
            )
            ax.add_patch(ellipse)
