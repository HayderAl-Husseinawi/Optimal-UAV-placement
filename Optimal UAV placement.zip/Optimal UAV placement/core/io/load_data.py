
import pandas as pd

from core.utils.geo import GeoUtils

def load_turbine_data(path: str) -> pd.DataFrame:
        """
        Read turbine data from an Excel file and convert coordinates to decimal degrees.
        Returns a DataFrame related to the raw data.
        To get Domain Objects, see get_turbines.
        """
        df = pd.read_excel(path, engine='openpyxl')

        # Split the 'Coordinates' column into latitude and longitude strings
        df[['latitude', 'longitude']] = df['Coordinates'].str.split(' ', expand=True)

        # Convert latitude and longitude from DMM to decimal degrees using GeoUtils
        # Standard convention: x = longitude (East-West), y = latitude (North-South)
        df['x'] = df['longitude'].apply(GeoUtils.dmm_to_dd)
        df['y'] = df['latitude'].apply(GeoUtils.dmm_to_dd)

        return df