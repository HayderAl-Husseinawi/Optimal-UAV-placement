from random import choice, random, sample, shuffle
from typing import List
import numpy as np
from mealpy import BinaryVar, FloatVar
from mealpy import SHADE, GA, NRO, ABC, GWO, WOA, DO, BA, PSO, BBO, CoatiOA, CDO
from core.io.plotter import Plotter
from core.model.drone import Drone
from core.model.shared import PhysicalState
from core.model.turbine import Turbine
from core.algorithms.multitask import Multitask
from core.utils.geo import GeoUtils
from core.utils.setting import Settings


class OptimizationManager:
    def __init__(
        self,
        physical_state: PhysicalState,
        results_path,
        target_drone_count=None,
    ):
        self.physical_state: PhysicalState = physical_state
        self.epochs = Settings.epochs
        self.trials = Settings.trials
        self.pop_size = Settings.pop_size
        self.results_path = results_path
        self.distance_matrix = GeoUtils.compute_distance_matrix(
            physical_state.drones, physical_state.turbines
        )
        self.target_drone_count = target_drone_count

    def apply_optimized_capacities(self, solution):
        """
        Permanently update physical_state drone capacities based on optimized solution.
        Call this AFTER optimization completes.
        """
        n_drones = self.physical_state.num_drones
        drone_state_sols = solution[:n_drones]
        drone_capacity_sols = solution[n_drones:]

        # Update capacity for each selected drone
        for i, (state, capacity) in enumerate(
            zip(drone_state_sols, drone_capacity_sols)
        ):
            if state > 0.5:  # Drone is selected
                new_capacity = int(round(capacity))
                drone = self.physical_state.drones[i]

                if drone.max_coverage != new_capacity:
                    self.physical_state.update_drone_by_id(
                        drone_id=drone.id, max_coverage=new_capacity
                    )

    def get_coverage(self, solution):
        """
        Evaluate coverage for a given solution.
        Does NOT modify physical_state permanently.
        """
        drone_state_sols = solution
        drone_capacity_overrides = {}  # Temporary overrides, don't modify state

        # Select active drones
        selected_indices = [i for i, val in enumerate(drone_state_sols) if val > 0.5]
        selected_drones = [self.physical_state.drones[i] for i in selected_indices]

        covered_turbines = set()
        placements = {}

        # Process drones in order (greedy assignment)
        for d_idx, drone in zip(selected_indices, selected_drones):
            # Get effective capacity (from override or drone's current capacity)
            max_capacity = drone_capacity_overrides.get(d_idx, drone.max_coverage)

            # Get reachable uncovered turbines
            reachable_uncovered = []
            for t_idx, turbine in enumerate(self.physical_state.turbines):
                if t_idx in covered_turbines:
                    continue

                dist = self.distance_matrix[d_idx][t_idx]
                if dist <= drone.get_radius():
                    reachable_uncovered.append((dist, t_idx))

            # Sort by distance (closest first) for deterministic, optimal assignment
            reachable_uncovered.sort()

            # Assign up to max_capacity turbines
            drone_coverage = []
            for dist, t_idx in reachable_uncovered:
                if len(drone_coverage) >= max_capacity:
                    break

                # Gain
                delta_gain = len(drone_coverage)

                # Update
                covered_turbines.add(t_idx)
                drone_coverage.append(t_idx)

            if drone_coverage:
                placements[drone.id] = drone_coverage

        num_drones_used = len(placements)
        num_uncovered = len(self.physical_state.turbines) - len(covered_turbines)

        num_drones_used = num_drones_used + 1
        loss = 1 - (delta_gain / Settings.drone_max_coverage)

        return num_drones_used, num_uncovered, placements, loss

    def objective_function(self, solution):
        num_drones_used, num_uncovered, _, loss = self.get_coverage(solution)
        # Normal mode: minimize drones while ensuring full coverage
        penalty = 100000 * num_uncovered
        return num_drones_used + penalty + loss

    def _create_problem(self):

        # Hold drone state (ON | OFF)
        n_vars = self.physical_state.num_drones
        lb = [0.0] * n_vars
        ub = [1.0] * n_vars

        # Hold drone coverage (5,6,7,8,9 etc.)
        problem = {
            "bounds": FloatVar(lb, ub),
            "obj_func": self.objective_function,
            "minmax": "min",
            "name": "Placements of drones",
            "log_to": "console",
        }
        return problem

    def optimize(self):
        algorithms = [
            GA.BaseGA(epoch=self.epochs, pop_size=self.pop_size, name="GA"),
            GWO.OriginalGWO(epoch=self.epochs, pop_size=self.pop_size, name="GWO"),
            PSO.OriginalPSO(epoch=self.epochs, pop_size=self.pop_size, name="PSO"),
        ]

        problem = self._create_problem()

        multitask = Multitask(
            optimizer=self,
            physical_state=self.physical_state,
            algorithms=algorithms,
            problems=[problem],
            # modes=("thread",),
            # n_workers=10,
            turbines=self.physical_state.turbines,
            drones=self.physical_state.drones,
        )
        results = multitask.execute(
            n_trials=self.trials,
            # n_jobs=2,
            save_path=self.results_path,
            save_as="csv",
            save_convergence=True,
            verbose=False,
        )

        # Get best result across all algorithms
        best_algo_name = None
        best_avg_fitness = float("inf")
        best_solution = None

        for algo_name, res in results.items():
            if res["avg_fitness"] < best_avg_fitness:
                best_avg_fitness = res["avg_fitness"]
                best_solution = res["solution"]
                best_algo_name = algo_name
        _, _, placements, _ = self.get_coverage(best_solution)

        final_placements = {k: v for k, v in placements.items() if len(v) > 0}
        selected_indices = list(final_placements.keys())
        return {
            "selected_drones_indices": selected_indices,
            "placements": final_placements,
            "best_algo_name": best_algo_name,
        }
