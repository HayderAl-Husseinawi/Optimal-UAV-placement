from typing import Union, List, Tuple
import pandas as pd
from pathlib import Path
from mealpy.optimizer import Optimizer
from mealpy.utils.validator import Validator
from functools import partial
import concurrent.futures as parallel
from copy import deepcopy
import os
import numpy as np
from core.io.plotter import Plotter
from core.model.shared import PhysicalState


class Multitask:
    def __init__(
        self,
        optimizer,
        physical_state: PhysicalState,
        algorithms: Union[List, Tuple] = None,
        problems: Union[List, Tuple] = None,
        terminations: Union[List, Tuple] = None,
        modes: Union[List, Tuple] = None,
        n_workers: int = None,
        **kwargs: object,
    ) -> None:
        self.__set_keyword_arguments(kwargs)
        self.validator = Validator(log_to="console", log_file=None)
        self.algorithms = self.validator.check_list_tuple(
            "algorithms", algorithms, "Optimizer"
        )
        self.problems = self.validator.check_list_tuple("problems", problems, "Problem")
        self.n_algorithms = len(self.algorithms)
        self.m_problems = len(self.problems)
        self.terminations = self.check_input(
            "terminations", terminations, "Termination"
        )
        self.modes = self.check_input(
            "modes", modes, "str (thread, process, single, swarm)"
        )
        self.n_workers = n_workers

        self.physical_state: PhysicalState = physical_state
        self.optimizer = optimizer

    def check_input(self, name=None, values=None, kind=None):
        if values is None:
            return None
        elif type(values) in (list, tuple):
            if len(values) == 1:
                values_final = [
                    [deepcopy(values[0]) for _ in range(0, self.m_problems)]
                    for _ in range(0, self.n_algorithms)
                ]
            elif len(values) == self.n_algorithms:
                values_final = [
                    deepcopy(values[idx] for _ in range(0, self.m_problems))
                    for idx in range(0, self.n_algorithms)
                ]
            elif len(values) == self.m_problems:
                values_final = [deepcopy(values) for _ in range(0, self.n_algorithms)]
            elif len(values) == (self.n_algorithms * self.m_problems):
                values_final = values
            else:
                raise ValueError(
                    f"{name} should be list of {kind} instances with size (1) or (n) or (m) or (n*m), n: #algorithms, m: #problems."
                )
            return values_final
        else:
            raise ValueError(f"{name} should be list of {kind} instances.")

    def __set_keyword_arguments(self, kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)

    @staticmethod
    def export_to_dataframe(result: pd.DataFrame, save_path: str):
        result.to_pickle(f"{save_path}.pkl")

    @staticmethod
    def export_to_json(result: pd.DataFrame, save_path: str):
        result.to_json(f"{save_path}.json")

    @staticmethod
    def export_to_csv(result: pd.DataFrame, save_path: str):
        result.to_csv(f"{save_path}.csv", header=True, index=False)

    def __run__(
        self,
        id_trial,
        optimizer,
        problem,
        termination=None,
        mode="single",
        starting_solutions=None,
    ):
        g_best = optimizer.solve(
            problem,
            mode=mode,
            termination=termination,
            n_workers=self.n_workers,
            starting_solutions=starting_solutions,
        )
        return {
            "id_trial": id_trial,
            "best_fitness": g_best.target.fitness,
            "solution": g_best.solution,  # Added by Hayder
            "convergence": optimizer.history.list_global_best_fit,
            "problem_name": optimizer.problem.get_name(),
        }

    def save_placements(self, result, optimizer, save_path):
        path_placement = f"{save_path}/placements/{optimizer.get_name()}"
        Path(path_placement).mkdir(parents=True, exist_ok=True)
        plt = Plotter(save_path=path_placement)

        _, _, placements, _ = self.optimizer.get_coverage(result["solution"])

        final_placements = {k: v for k, v in placements.items() if len(v) > 0}
        selected_drones_indices = list(final_placements.keys())
        # selected_drones = [idx for idx, val in enumerate(best_candidate_drone) if val == 1]

        # Placements
        plt.plot_drones_turbines(
            turbines=self.physical_state.turbines,
            drones=[self.physical_state.drones[i] for i in selected_drones_indices],
            filename=f"Placement_by_{optimizer.get_name()}_trial_{result['id_trial']}",
        )

    def execute(
        self,
        n_trials: int = 2,
        n_jobs: int = None,
        save_path: str = "history",
        save_as: str = "csv",
        save_convergence: bool = False,
        verbose: bool = False,
        starting_solutions: list = None,
    ) -> dict:

        n_trials = self.validator.check_int("n_trials", n_trials, [1, 100000])
        n_processors = None
        if (n_jobs is not None) and (n_jobs >= 1):
            n_processors = self.validator.check_int(
                "n_jobs", n_jobs, [2, min(61, os.cpu_count() - 1)]
            )

        ## Get export function
        save_as = self.validator.check_str(
            "save_as", save_as, ["csv", "json", "dataframe"]
        )
        export_function = getattr(self, f"export_to_{save_as}")

        # Dictionary to store the best result for each optimizer
        final_results = {}

        for id_optimizer, optimizer in enumerate(self.algorithms):
            # Create directories for best fit and convergence
            path_best_fit = f"{save_path}/best_fit"
            path_convergence = f"{save_path}/convergence/{optimizer.get_name()}"
            Path(path_best_fit).mkdir(parents=True, exist_ok=True)
            Path(path_convergence).mkdir(parents=True, exist_ok=True)

            if not isinstance(optimizer, Optimizer):
                print(f"Model: {id_optimizer+1} is not an instance of Optimizer class.")
                continue
            best_fit_optimizer_results = {}
            for id_prob, problem in enumerate(self.problems):
                term = None
                if self.terminations is not None:
                    term = self.terminations[id_optimizer][id_prob]

                mode = "single"
                if self.modes is not None:
                    mode = self.modes[id_optimizer][id_prob]

                convergence_trials = {}
                best_fit_trials = []
                trial_list = list(range(1, n_trials + 1))

                if n_processors is not None:
                    with parallel.ProcessPoolExecutor(n_processors) as executor:
                        list_results = executor.map(
                            partial(
                                self.__run__,
                                optimizer=optimizer,
                                problem=problem,
                                termination=term,
                                mode=mode,
                                starting_solutions=starting_solutions,
                            ),
                            trial_list,
                        )
                        for result in list_results:
                            convergence_trials[f"trial_{result['id_trial']}"] = result[
                                "convergence"
                            ]
                            best_fit_trials.append(result["best_fitness"])

                            # Update best solution found so far for this optimizer
                            avg_fitness = np.mean(best_fit_trials)

                            opt_name = optimizer.get_name()
                            avg_fitness = np.mean(best_fit_trials)
                            std_fitness = np.std(best_fit_trials)

                            # find best trial (optional, just to keep best solution)
                            best_idx = np.argmin(best_fit_trials)

                            final_results[opt_name] = {
                                "avg_fitness": avg_fitness,
                                "std_fitness": std_fitness,
                                "best_fitness": best_fit_trials[best_idx],
                                "solution": result[
                                    "solution"
                                ],  # better fix below if needed
                                "trial_id": best_idx + 1,
                            }

                            # Save selected drone
                            self.save_placements(
                                result=result, optimizer=optimizer, save_path=save_path
                            )

                            if verbose:
                                print(
                                    f"Solving problem: {result['problem_name']} using algorithm: {optimizer.get_name()}, on the: {result['id_trial']} trial"
                                )
                else:
                    for idx in trial_list:
                        result = self.__run__(
                            idx,
                            optimizer,
                            problem,
                            termination=term,
                            mode=mode,
                            starting_solutions=starting_solutions,
                        )
                        convergence_trials[f"trial_{result['id_trial']}"] = result[
                            "convergence"
                        ]
                        best_fit_trials.append(result["best_fitness"])

                        # Update best solution found so far for this optimizer
                        opt_name = optimizer.get_name()
                        avg_fitness = np.mean(best_fit_trials)
                        std_fitness = np.std(best_fit_trials)

                        # find best trial (optional, just to keep best solution)
                        best_idx = np.argmin(best_fit_trials)

                        final_results[opt_name] = {
                            "avg_fitness": avg_fitness,
                            "std_fitness": std_fitness,
                            "best_fitness": best_fit_trials[best_idx],
                            "solution": result[
                                "solution"
                            ],  # better fix below if needed
                            "trial_id": best_idx + 1,
                        }

                        # Save selected drone and reduced drones
                        self.save_placements(
                            result=result, optimizer=optimizer, save_path=save_path
                        )

                        if verbose:
                            print(
                                f"Solving problem: {result['problem_name']} using algorithm: {optimizer.get_name()}, on the: {result['id_trial']} trial"
                            )

                best_fit_optimizer_results[result["problem_name"]] = best_fit_trials
                if save_convergence:
                    max_length = max([len(col) for col in convergence_trials.values()])
                    for kk, vv in convergence_trials.items():
                        convergence_trials[kk] = list(vv) + [float("nan")] * (
                            max_length - len(vv)
                        )
                    df1 = pd.DataFrame(convergence_trials)
                    export_function(df1, f"{path_convergence}/{result['problem_name']}")

            df2 = pd.DataFrame(best_fit_optimizer_results)
            export_function(df2, f"{path_best_fit}/{optimizer.get_name()}")

        return final_results
