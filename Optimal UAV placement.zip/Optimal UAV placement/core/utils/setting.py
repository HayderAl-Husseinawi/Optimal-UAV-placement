from dataclasses import dataclass
from datetime import datetime

from typing import List


@dataclass
class Settings:
    # Paths
    data_name: str = "walney"
    turbine_data_path: str = f"data/{data_name}/{data_name}.xlsx"
    results_base_path: str = f"results/{data_name}"

    # DRONE
    drone_speed_mps: float = 8.0
    drone_max_flight_time_mins: float = 20.0
    drone_max_coverage: int = 5

    # OPTIMIZATION
    epochs: int = 100
    pop_size: int = 30
    trials: int = 3

    # CONSTANTS
    METERS_PER_DEGREE: int = 111_320

    # 🔹 STATIC (per run)
    TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

    def get_results_path() -> str:
        return f"{Settings.results_base_path}/{Settings.TIMESTAMP}"


# Global instance for backward compatibility if needed, or prefer dependency injection
# default_settings = Settings()
