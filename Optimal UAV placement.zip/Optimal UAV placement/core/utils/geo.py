import re
from typing import Tuple

import numpy as np

from core.utils.setting import Settings


class GeoUtils:
    """
    A utility class for geographic coordinate conversions and calculations.
    """

    @staticmethod
    def dmm_to_dd(coord: str) -> float:
        """
        Convert coordinates from Degrees and Decimal Minutes (DMM) format to Decimal Degrees (DD).

        Args:
            coord (str): Coordinate string in the format "DDD°MM.MMMM'N|S|E|W".

        Returns:
            float: Decimal degrees representation of the coordinate
        """
        pattern = r"(\d+)°(\d+\.\d+)'([NSEW])"
        match = re.match(pattern, coord)
        if not match:
            return None

        degrees = float(match.group(1))
        minutes = float(match.group(2))
        direction = match.group(3)

        decimal_degrees = degrees + minutes / 60
        if direction in ["S", "W"]:
            decimal_degrees *= -1

        return decimal_degrees

    @staticmethod
    def distance(p1: Tuple[float, float], p2: Tuple[float, float]) -> float:
        """
        Calculate Euclidean distance between two points.

        Args:
            p1 (tuple): (x, y) coordinates of point 1.
            p2 (tuple): (x, y) coordinates of point 2.

        Returns:
            float: Euclidean distance.
        """
        return (
            ((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2) ** 0.5
        ) * Settings.METERS_PER_DEGREE

    @staticmethod
    def compute_distance_matrix(drones, turbines):
        """Compute distances from each DRONE to each TURBINE"""
        n_drones = len(drones)
        n_turbines = len(turbines)
        matrix = np.zeros((n_drones, n_turbines))
        for d_idx, drone in enumerate(drones):
            for t_idx, turbine in enumerate(turbines):
                matrix[d_idx][t_idx] = GeoUtils.distance(
                    (drone.x, drone.y), (turbine.x, turbine.y)
                )
        return matrix
