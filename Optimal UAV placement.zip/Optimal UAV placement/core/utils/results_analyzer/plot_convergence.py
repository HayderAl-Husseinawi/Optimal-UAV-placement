import os
import warnings
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl

mpl.rcParams["font.family"] = "times new roman"
colors = [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#637939",
    "#9467bd",
    "#8c564b",
    "#e377c2",
    "#7f7f7f",
    "#bcbd22",
    "#17becf",
    "#393b79",
    "#d62728",
    "#8c6d31",
    "#843c39",
    "#7b4173",
    "#a55194",
    "#6b6ecf",
    "#ce6dbd",
    "#9c9ede",
    "#bd9e39",
]


# def _smoothData(data, win_size):
#     return np.convolve(data, np.ones(win_size) / win_size, mode="valid")


def plot_convergence_of_results(results_path):
    warnings.filterwarnings("ignore", category=RuntimeWarning)

    base_path = os.path.join(results_path, "convergence")
    save_dir = os.path.join(results_path, "results_analysis/FIGURES/convergence")

    os.makedirs(save_dir, exist_ok=True)

    algorithms = os.listdir(base_path)
    function_files = os.listdir(os.path.join(base_path, algorithms[0]))
    algorithms.sort()

    for func_file in function_files:
        plt.figure(figsize=(4, 4))
        ax = plt.gca()

        all_avg_curves = []
        final_fitnesses = []
        labels = []

        for i, optimizer in enumerate(algorithms):
            file_path = os.path.join(base_path, optimizer, func_file)
            df = pd.read_csv(file_path, sep=",")
            avg_curve = df.mean(axis=1).values
            # avg_curve = _smoothData(avg_curve, win_size=50)
            all_avg_curves.append(avg_curve)
            labels.append(optimizer)

            x = np.arange(len(avg_curve))
            ax.plot(
                x,
                avg_curve,
                label=optimizer,
                color=colors[i % len(colors)],
                linewidth=0.5,
            )
            ax.plot(
                x[-1],
                avg_curve[-1],
                marker="o",
                color=colors[i % len(colors)],
                markersize=1.5,
            )

            final_fitnesses.append((avg_curve[-1], optimizer))

        # Axis labels and title
        ax.set_title(f"{func_file.replace('.csv','')}", fontsize=9)
        ax.set_xlabel("Epochs", fontsize=8)
        ax.set_ylabel("Fitness", fontsize=8)
        ax.tick_params(axis="x", labelsize=8)
        ax.tick_params(axis="y", labelsize=8)
        ax.legend(fontsize=9)
        ax.set_yscale("log")

        # Save to PDF
        plt.tight_layout()
        save_path = os.path.join(save_dir, f"{func_file.replace('.csv', '')}.svg")
        plt.savefig(save_path, format="svg", bbox_inches="tight", pad_inches=0)
        plt.close()

    print("Convergence plots saved successfully")
